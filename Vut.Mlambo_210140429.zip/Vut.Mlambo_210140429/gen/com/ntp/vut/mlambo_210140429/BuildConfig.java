/** Automatically generated file. DO NOT MODIFY */
package com.ntp.vut.mlambo_210140429;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}