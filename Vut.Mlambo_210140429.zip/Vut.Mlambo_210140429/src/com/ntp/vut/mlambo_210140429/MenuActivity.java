package com.ntp.vut.mlambo_210140429;

import android.os.Bundle;
import android.provider.Settings.System;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MenuActivity extends Activity {
Integer[] foodArray={R.drawable.food1_frenchpankake,R.drawable.food2_burgerchips,R.drawable.food3_mexican,R.drawable.food4_frenchburger,R.drawable.drink1_cocktail,R.drawable.drink2_colddrink,R.drawable.drink3_juice};
Integer[] priceArray={1500,2000,3000,1000,500,250,350};
Gallery gal;
ImageView img;
Integer UnitPrice;
Integer Quantity;
int Total;
int resTotal;
double FullAmt;
int Tip;
int Items;
double Totorder;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menuactivity_menu);
	gal=(Gallery)findViewById(R.id.gallery1);
	img=(ImageView)findViewById(R.id.imageView1);
	gal.setAdapter( new ImageAdapter(this));
	
	Button btnAdd=(Button)findViewById(R.id.btnAdd);
	Button btnreset=(Button)findViewById(R.id.btnReset);
	Button btnfinish=(Button)findViewById(R.id.btnFinish);
	
	final TextView lblunitp=(TextView)findViewById(R.id.txtUnitp);
	final EditText QTY=(EditText)findViewById(R.id.editText1);
	final TextView order=(TextView)findViewById(R.id.txorder);
	final TextView TotItems=(TextView)findViewById(R.id.txTotItems);
	TextView Tips=(TextView)findViewById(R.id.txTip);
	TextView Fullamt=(TextView)findViewById(R.id.txFullamt);
	
btnAdd.setOnClickListener(new OnClickListener() {
	
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
		Quantity=Integer.parseInt(QTY.getText().toString());
		
		Total=resTotal;
		Total=Quantity*UnitPrice;
		order.setText(Total);
		
		if(Totorder >1000 ||Totorder <2000){
			Totorder=Total+0.5;
			
			}
		if(Totorder>2000|| Totorder<5000){
			Totorder=Total+0.15;
			
		}
		if(Totorder>5000){
			Totorder=Total+0.2;
		}
		if(Totorder<1000){
		Toast tt=Toast.makeText(MenuActivity.this, "your order is bellow R1000 and a tip for R100 is added", Toast.LENGTH_LONG);tt.show();
		Totorder=Total+100;
		}
		
		FullAmt= Tip+Totorder;
		TotItems.setText(Items);
		
	}
});
	btnreset.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			onRestart();
		}
	});
	
	btnfinish.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			Toast tt=Toast.makeText(MenuActivity.this, "Thank You Call Again", Toast.LENGTH_LONG);tt.show();
			startActivity(new Intent(MenuActivity.this,MainActivity.class));
			
			
		}
	});
	
	
	gal.setOnItemClickListener(new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			img.setImageResource(foodArray[arg2]);
			UnitPrice=Integer.parseInt(lblunitp.getText().toString());
			
			lblunitp.setText(priceArray.toString());
			
			
		}
	});
	}

	public class ImageAdapter extends BaseAdapter{
Context context;
public ImageAdapter(Context c){
	context=c;
}
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			int len;
			len=foodArray.length;
			return len;
		}

		@Override
		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public View getView(int arg0, View arg1, ViewGroup arg2) {
			ImageView pic=new ImageView(context);
			pic.setImageResource(foodArray[arg0]);
			pic.setScaleType(ImageView.ScaleType.FIT_XY);
			pic.setLayoutParams(new Gallery.LayoutParams(80, 80));
			return pic;
		}
		
	}

}
