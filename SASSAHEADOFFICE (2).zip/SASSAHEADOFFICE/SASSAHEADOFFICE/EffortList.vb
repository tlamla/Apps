﻿Public Class EffortList

End Class