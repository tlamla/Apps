﻿Imports System.Data
Imports System.Data.SqlClient

Public Class MonitorAsset

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmbmodel.SelectedIndexChanged

    End Sub

    Private Sub MonitorAsset_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Cmbmodel.Items.Add("Dell")
        Cmbmodel.Items.Add("Proline")
        Cmbmodel.Items.Add("HP")
        Cmbmodel.Items.Add("Accer")
        Cmbmodel.Items.Add("Microsoft")
        Cmbmodel.Items.Add("Avoc")


        CmbConnector.Items.Add("VGA")
        CmbConnector.Items.Add("DVI")
        CmbConnector.Items.Add("HDMI")

        CmbConnectedTo.Items.Add("Base Unit")
        CmbConnectedTo.Items.Add("NoteBook")
        CmbConnectedTo.Items.Add("Tablet")
        CmbConnectedTo.Items.Add("Docking Station")

        CmbCondition.Items.Add("Good")
        CmbCondition.Items.Add("Fair")
        CmbCondition.Items.Add("Poor")



    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim connection As String = "Data Source=USER-PC\SVR2K01;Initial Catalog=HeadOffice;Integrated Security=True;Pooling=False"
        Dim conobj As New SqlConnection(connection)
        conobj.Open()

        Dim qry As String = "Insert INTO Monitor_Asset (Asset_no,Model, Connector, connect_to, Asset_code, condition, Date_prepared, General_remarks) values(@Asset_no,@Model, @Connector, @connect_to, @Asset_code, @condition,@Date_prepared, @General_remarks)"
        'Dim qry As String = "insert into tblAgent (Name,Surname,DOB) values (@Name,@Surname,@DOB)"
        'Dim conectionobj As New SqlConnection(conncetion)
        Dim cmd As New SqlCommand(qry, conobj)

        cmd.Parameters.Add("@Asset_no", SqlDbType.VarChar).Value = TextBox1.Text
        cmd.Parameters.Add("@Asset_code", SqlDbType.VarChar).Value = TxtCode.Text
        cmd.Parameters.Add("@Model", SqlDbType.VarChar).Value = CStr(Cmbmodel.SelectedItem)
        cmd.Parameters.Add("@Connector", SqlDbType.VarChar).Value = CmbConnector.SelectedItem
        cmd.Parameters.Add("@Connect_to", SqlDbType.VarChar).Value = CmbConnectedTo.SelectedItem
        cmd.Parameters.Add("@condition", SqlDbType.VarChar).Value = CmbCondition.SelectedItem
        cmd.Parameters.Add("@Date_prepared", SqlDbType.VarChar).Value = CDate(DateTimePicker1.Text)
        cmd.Parameters.Add("@General_remarks", SqlDbType.VarChar).Value = TxtRemarks.Text


        'conobj.Open()
        cmd.ExecuteNonQuery()

        conobj.Close()
        MsgBox("Record saved")
        'Dim da As New SqlDataAdapter(qry, conobj)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnUpdate.Click
        Dim connection As String = "Data Source=USER-PC\SVR2K01;Initial Catalog=HeadOffice;Integrated Security=True;Pooling=False"
        Dim conobj As New SqlConnection(connection)
        'conobj.Open()

        Dim qry As String = "Update Monitor_Asset set Asset_no=@Asset_no,Model=@Model,Connector=@Connector,connect_to=@connect_to,Asset_code=@Asset_code,condition=@condition,Date_prepared=@Date_prepared,General_remarks=@General_remarks where (Asset_no=@Asset_no)"
        'Dim qry As String = "insert into tblAgent (Name,Surname,DOB) values (@Name,@Surname,@DOB)"
        'Dim conectionobj As New SqlConnection(conncetion)
        Dim cmd As New SqlCommand(qry, conobj)

        cmd.Parameters.Add("@Asset_no", SqlDbType.VarChar).Value = TextBox1.Text
        cmd.Parameters.Add("@Asset_code", SqlDbType.VarChar).Value = TxtCode.Text
        cmd.Parameters.Add("@Model", SqlDbType.VarChar).Value = CStr(Cmbmodel.SelectedItem)
        cmd.Parameters.Add("@Connector", SqlDbType.VarChar).Value = CmbConnector.SelectedItem
        cmd.Parameters.Add("@Connect_to", SqlDbType.VarChar).Value = CmbConnectedTo.SelectedItem
        cmd.Parameters.Add("@condition", SqlDbType.VarChar).Value = CmbCondition.SelectedItem
        cmd.Parameters.Add("@Date_prepared", SqlDbType.VarChar).Value = CDate(DateTimePicker1.Text)
        cmd.Parameters.Add("@General_remarks", SqlDbType.VarChar).Value = TxtRemarks.Text

        conobj.Open()
        cmd.ExecuteNonQuery()

        'conobj.Close()
        MsgBox("Record updated")
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDelete.Click
        Dim connection As String = "Data Source=USER-PC\SVR2K01;Initial Catalog=HeadOffice;Integrated Security=True;Pooling=False"
        Dim conobj As New SqlConnection(connection)


        Dim qry As String = "Delete from Monitor_Asset where (Asset_no=@Asset_no)"
        'Dim qry As String = "insert into tblAgent (Name,Surname,DOB) values (@Name,@Surname,@DOB)"
        'Dim conectionobj As New SqlConnection(conncetion)
        Dim cmd As New SqlCommand(qry, conobj)
        cmd.Parameters.Add("@Asset_no", SqlDbType.VarChar).Value = TextBox1.Text

        conobj.Open()
        cmd.ExecuteNonQuery()

        'conobj.Close()

        MsgBox("Record Deleted")

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExit.Click
        Me.Close()
    End Sub
End Class