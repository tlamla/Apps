﻿Public Class SiteDetails

End Class