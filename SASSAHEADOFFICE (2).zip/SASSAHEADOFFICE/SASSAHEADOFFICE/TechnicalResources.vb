﻿Public Class TechnicalResources

End Class