﻿Public Class Form1

    Private Sub UserTableToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UserTableToolStripMenuItem.Click
        Dim UserTable As New UserTable
        UserTable.MdiParent = Me
        UserTable.Show()
    End Sub

    Private Sub ComputerAssetsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComputerAssetsToolStripMenuItem.Click
        Dim computerAsset As New ComputerAsset
        computerAsset.MdiParent = Me
        computerAsset.Show()
    End Sub

    Private Sub MonitorAssetToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MonitorAssetToolStripMenuItem.Click
        Dim MonitorAsset As New MonitorAsset
        MonitorAsset.MdiParent = Me
        MonitorAsset.Show()
    End Sub

    Private Sub PrinterAssetToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrinterAssetToolStripMenuItem.Click
        Dim printerAsset As New PrinterAsset
        printerAsset.MdiParent = Me
        printerAsset.Show()
    End Sub

    Private Sub SoftwaresToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SoftwaresToolStripMenuItem.Click
        Dim software As New Softwares
        Softwares.MdiParent = Me
        Softwares.Show()
    End Sub

    Private Sub SiteDetailsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SiteDetailsToolStripMenuItem.Click
        Dim sitedetails As New SiteDetails
        sitedetails.MdiParent = Me
        sitedetails.Show()
    End Sub

    Private Sub EffortListToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EffortListToolStripMenuItem.Click
        Dim EffortList As New EffortList
        EffortList.MdiParent = Me
        EffortList.Show()
    End Sub

    Private Sub SiteEffortToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SiteEffortToolStripMenuItem.Click
        Dim siteEffort As New SiteEfforts
        SiteEfforts.MdiParent = Me
        SiteEfforts.Show()
    End Sub

    Private Sub TechnicalResourcesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TechnicalResourcesToolStripMenuItem.Click
        Dim resources As New TechnicalResources
        TechnicalResources.MdiParent = Me
        TechnicalResources.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub ComputerAssetReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComputerAssetReportToolStripMenuItem.Click
        Dim computer As New ComputerAssetReport
        ComputerAssetReport.MdiParent = Me
        ComputerAssetReport.Show()
    End Sub

    Private Sub EffortListReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EffortListReportToolStripMenuItem.Click
        Dim Effort As New EffortListReport
        EffortListReport.MdiParent = Me
        EffortListReport.Show()
    End Sub

    Private Sub ListOfUsersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfUsersToolStripMenuItem.Click
        Dim users As New ListOfUsers
        ListOfUsers.MdiParent = Me
        ListOfUsers.Show()
    End Sub

    Private Sub MonitorAssetReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MonitorAssetReportToolStripMenuItem.Click
        Dim monitor As New MonitorAssetReport
        MonitorAssetReport.MdiParent = Me
        MonitorAssetReport.Show()
    End Sub

    Private Sub PrinterAssetReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrinterAssetReportToolStripMenuItem.Click
        Dim printer As New PrinterAssetReport
        PrinterAssetReport.MdiParent = Me
        PrinterAssetReport.Show()
    End Sub

    Private Sub SiteDetailsReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SiteDetailsReportToolStripMenuItem.Click
        Dim site As New SiteDetailsReport
        SiteDetailsReport.MdiParent = Me
        SiteDetailsReport.Show()
    End Sub

    Private Sub SiteEffortReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SiteEffortReportToolStripMenuItem.Click
        Dim siteEff As New siteEffortReport
        siteEffortReport.MdiParent = Me
        siteEffortReport.Show()
    End Sub

    Private Sub ListOfSoftwaresToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListOfSoftwaresToolStripMenuItem.Click
        Dim software As New softwareReport
        softwareReport.MdiParent = Me
        softwareReport.Show()
    End Sub

    Private Sub TechnicalResourceReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TechnicalResourceReportToolStripMenuItem.Click
        Dim TechnicalR As New TechnicalResReport
        TechnicalResReport.MdiParent = Me
        TechnicalResReport.Show()
    End Sub
End Class
