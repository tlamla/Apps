﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UserTableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComputerAssetsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MonitorAssetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrinterAssetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SoftwaresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SiteDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EffortListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SiteEffortToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TechnicalResourcesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComputerAssetReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EffortListReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfUsersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MonitorAssetReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrinterAssetReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SiteDetailsReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SiteEffortReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfSoftwaresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TechnicalResourceReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuToolStripMenuItem, Me.ReportsToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(602, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MenuToolStripMenuItem
        '
        Me.MenuToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UserTableToolStripMenuItem, Me.ComputerAssetsToolStripMenuItem, Me.MonitorAssetToolStripMenuItem, Me.PrinterAssetToolStripMenuItem, Me.SoftwaresToolStripMenuItem, Me.SiteDetailsToolStripMenuItem, Me.EffortListToolStripMenuItem, Me.SiteEffortToolStripMenuItem, Me.TechnicalResourcesToolStripMenuItem})
        Me.MenuToolStripMenuItem.Name = "MenuToolStripMenuItem"
        Me.MenuToolStripMenuItem.Size = New System.Drawing.Size(50, 20)
        Me.MenuToolStripMenuItem.Text = "Menu"
        '
        'UserTableToolStripMenuItem
        '
        Me.UserTableToolStripMenuItem.Name = "UserTableToolStripMenuItem"
        Me.UserTableToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.UserTableToolStripMenuItem.Text = "User Table"
        '
        'ComputerAssetsToolStripMenuItem
        '
        Me.ComputerAssetsToolStripMenuItem.Name = "ComputerAssetsToolStripMenuItem"
        Me.ComputerAssetsToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ComputerAssetsToolStripMenuItem.Text = "Computer Assets"
        '
        'MonitorAssetToolStripMenuItem
        '
        Me.MonitorAssetToolStripMenuItem.Name = "MonitorAssetToolStripMenuItem"
        Me.MonitorAssetToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.MonitorAssetToolStripMenuItem.Text = "Monitor Asset"
        '
        'PrinterAssetToolStripMenuItem
        '
        Me.PrinterAssetToolStripMenuItem.Name = "PrinterAssetToolStripMenuItem"
        Me.PrinterAssetToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.PrinterAssetToolStripMenuItem.Text = "Printer Asset"
        '
        'SoftwaresToolStripMenuItem
        '
        Me.SoftwaresToolStripMenuItem.Name = "SoftwaresToolStripMenuItem"
        Me.SoftwaresToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.SoftwaresToolStripMenuItem.Text = "Softwares"
        '
        'SiteDetailsToolStripMenuItem
        '
        Me.SiteDetailsToolStripMenuItem.Name = "SiteDetailsToolStripMenuItem"
        Me.SiteDetailsToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.SiteDetailsToolStripMenuItem.Text = "Site Details"
        '
        'EffortListToolStripMenuItem
        '
        Me.EffortListToolStripMenuItem.Name = "EffortListToolStripMenuItem"
        Me.EffortListToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.EffortListToolStripMenuItem.Text = "Effort List"
        '
        'SiteEffortToolStripMenuItem
        '
        Me.SiteEffortToolStripMenuItem.Name = "SiteEffortToolStripMenuItem"
        Me.SiteEffortToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.SiteEffortToolStripMenuItem.Text = "Site Effort"
        '
        'TechnicalResourcesToolStripMenuItem
        '
        Me.TechnicalResourcesToolStripMenuItem.Name = "TechnicalResourcesToolStripMenuItem"
        Me.TechnicalResourcesToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.TechnicalResourcesToolStripMenuItem.Text = "Technical Resources"
        '
        'ReportsToolStripMenuItem
        '
        Me.ReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ComputerAssetReportToolStripMenuItem, Me.EffortListReportToolStripMenuItem, Me.ListOfUsersToolStripMenuItem, Me.MonitorAssetReportToolStripMenuItem, Me.PrinterAssetReportToolStripMenuItem, Me.SiteDetailsReportToolStripMenuItem, Me.SiteEffortReportToolStripMenuItem, Me.ListOfSoftwaresToolStripMenuItem, Me.TechnicalResourceReportToolStripMenuItem})
        Me.ReportsToolStripMenuItem.Name = "ReportsToolStripMenuItem"
        Me.ReportsToolStripMenuItem.Size = New System.Drawing.Size(59, 20)
        Me.ReportsToolStripMenuItem.Text = "Reports"
        '
        'ComputerAssetReportToolStripMenuItem
        '
        Me.ComputerAssetReportToolStripMenuItem.Name = "ComputerAssetReportToolStripMenuItem"
        Me.ComputerAssetReportToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.ComputerAssetReportToolStripMenuItem.Text = "Computer Asset Report"
        '
        'EffortListReportToolStripMenuItem
        '
        Me.EffortListReportToolStripMenuItem.Name = "EffortListReportToolStripMenuItem"
        Me.EffortListReportToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.EffortListReportToolStripMenuItem.Text = "Effort List Report"
        '
        'ListOfUsersToolStripMenuItem
        '
        Me.ListOfUsersToolStripMenuItem.Name = "ListOfUsersToolStripMenuItem"
        Me.ListOfUsersToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.ListOfUsersToolStripMenuItem.Text = "List Of Users"
        '
        'MonitorAssetReportToolStripMenuItem
        '
        Me.MonitorAssetReportToolStripMenuItem.Name = "MonitorAssetReportToolStripMenuItem"
        Me.MonitorAssetReportToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.MonitorAssetReportToolStripMenuItem.Text = "Monitor Asset Report"
        '
        'PrinterAssetReportToolStripMenuItem
        '
        Me.PrinterAssetReportToolStripMenuItem.Name = "PrinterAssetReportToolStripMenuItem"
        Me.PrinterAssetReportToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.PrinterAssetReportToolStripMenuItem.Text = "Printer Asset report"
        '
        'SiteDetailsReportToolStripMenuItem
        '
        Me.SiteDetailsReportToolStripMenuItem.Name = "SiteDetailsReportToolStripMenuItem"
        Me.SiteDetailsReportToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.SiteDetailsReportToolStripMenuItem.Text = "Site Details Report"
        '
        'SiteEffortReportToolStripMenuItem
        '
        Me.SiteEffortReportToolStripMenuItem.Name = "SiteEffortReportToolStripMenuItem"
        Me.SiteEffortReportToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.SiteEffortReportToolStripMenuItem.Text = "Site Effort Report"
        '
        'ListOfSoftwaresToolStripMenuItem
        '
        Me.ListOfSoftwaresToolStripMenuItem.Name = "ListOfSoftwaresToolStripMenuItem"
        Me.ListOfSoftwaresToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.ListOfSoftwaresToolStripMenuItem.Text = "List of Softwares"
        '
        'TechnicalResourceReportToolStripMenuItem
        '
        Me.TechnicalResourceReportToolStripMenuItem.Name = "TechnicalResourceReportToolStripMenuItem"
        Me.TechnicalResourceReportToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.TechnicalResourceReportToolStripMenuItem.Text = "Technical Resource Report"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(602, 540)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "SASSA Basic ICT Assets"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MenuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UserTableToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ComputerAssetsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MonitorAssetToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrinterAssetToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SoftwaresToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SiteDetailsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EffortListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SiteEffortToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TechnicalResourcesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ComputerAssetReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EffortListReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfUsersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MonitorAssetReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrinterAssetReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SiteDetailsReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SiteEffortReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfSoftwaresToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TechnicalResourceReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
