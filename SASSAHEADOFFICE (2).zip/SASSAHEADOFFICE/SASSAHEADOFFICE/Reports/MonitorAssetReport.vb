﻿Imports System.Data.SqlClient
Imports System.Data

Public Class MonitorAssetReport

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub MonitorAssetReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim connection As String = "Data Source=USER-PC\SVR2K01;Initial Catalog=HeadOffice;Integrated Security=True;Pooling=False"
        Dim conobj As New SqlConnection(connection)
        conobj.Open()

        Dim qry As String = "select * from Monitor_Asset"
        'Dim qry As String = "insert into tblAgent (Name,Surname,DOB) values (@Name,@Surname,@DOB)"
        'Dim conectionobj As New SqlConnection(conncetion)
        Dim cmd As New SqlCommand(qry, conobj)

        Dim da As New SqlDataAdapter(qry, conobj)
        Dim dt As New DataTable("Monitor_Aseet")

        da.Fill(dt)
        DataGridView1.DataSource = dt

        'DataGridView1.DataBind()
        lbldisplayTotal.Text = "Total is: " + "" + DataGridView1.RowCount.ToString



    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Dim connection As String = "Data Source=USER-PC\SVR2K01;Initial Catalog=HeadOffice;Integrated Security=True;Pooling=False"
        Dim conobj As New SqlConnection(connection)
        conobj.Open()

        Dim commmand As New SqlCommand("select Asset_no,Model, Connector, connect_to, Asset_code, condition, Date_prepared, General_remarks from Monitor_Asset where Asset_no like'%" & TextBox1.Text & "%' or Model like '%" & TextBox1.Text & "%' or Connector like '%" & TextBox1.Text & "%' or connect_to like '%" & TextBox1.Text & "%' or Asset_code like '%" & TextBox1.Text & "%' or condition like '%" & TextBox1.Text & "%' or Date_prepared like '%" & TextBox1.Text & "%' or General_remarks like'%" & TextBox1.Text & "%'", conobj)
        ' Dim cmd As New SqlCommand("select Emp_no as [Emp_id],Name as [Name], Surname as [Surname] from Employee where Name like'%" & TextBox1.Text & "%' or Surname like'%" & TextBox1.Text & "%'", conobj)
        conobj.Close()
        conobj.Open()

        Dim data As New DataTable
        Dim adp As New SqlDataAdapter(commmand)


        adp.Fill(data)
        DataGridView1.DataSource = data
        DataGridView1.Refresh()
        commmand.Dispose()
        conobj.Close()
        lbldisplayTotal.Text = DataGridView1.RowCount.ToString + " : " + TextBox1.Text

    End Sub
End Class