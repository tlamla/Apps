﻿Public Class PrinterAsset

End Class