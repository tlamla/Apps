﻿namespace LottoNUmbers
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.lbldisplay = new System.Windows.Forms.Label();
            this.lottoDataSet = new LottoNUmbers.LottoDataSet();
            this.lottoDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.lottoDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lottoDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(90, 208);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(163, 41);
            this.btnGenerate.TabIndex = 0;
            this.btnGenerate.Text = "Generate Numbers";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // lbldisplay
            // 
            this.lbldisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbldisplay.Location = new System.Drawing.Point(90, 44);
            this.lbldisplay.Name = "lbldisplay";
            this.lbldisplay.Size = new System.Drawing.Size(188, 82);
            this.lbldisplay.TabIndex = 1;
            // 
            // lottoDataSet
            // 
            this.lottoDataSet.DataSetName = "LottoDataSet";
            this.lottoDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lottoDataSetBindingSource
            // 
            this.lottoDataSetBindingSource.DataSource = this.lottoDataSet;
            this.lottoDataSetBindingSource.Position = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.BackgroundImage = global::LottoNUmbers.Properties.Resources.lotto;
            this.ClientSize = new System.Drawing.Size(483, 332);
            this.Controls.Add(this.lbldisplay);
            this.Controls.Add(this.btnGenerate);
            this.Name = "Form1";
            this.Text = "Lotto Numbers Application";
            ((System.ComponentModel.ISupportInitialize)(this.lottoDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lottoDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Label lbldisplay;
        private System.Windows.Forms.BindingSource lottoDataSetBindingSource;
        private LottoDataSet lottoDataSet;
    }
}

