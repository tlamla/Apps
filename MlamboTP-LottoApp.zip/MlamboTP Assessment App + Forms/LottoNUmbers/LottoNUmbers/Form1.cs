﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LottoNUmbers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int num = random.Next(1, 49);
            lbldisplay.Text = Convert.ToString("Your lucky number is :"+ num);

              string   connectionstring = @"Data Source=TLANGELANI-PC\SQLEXPRESS;Initial Catalog=Lotto;Integrated Security=True";

              SqlConnection conn = new SqlConnection(connectionstring );
              conn.Open();
              
             SqlCommand cmd = new SqlCommand( );
             cmd.Connection = conn;
             string sqlquery = "INSERT into savenum (number) " + " VALUES ('" + num + "');";
             cmd.CommandText = sqlquery;
              cmd.ExecuteNonQuery();
      
              conn.Close();
            
            
     
            
              {          
            
    }
}

    }
}