﻿Public Class agent
    Private _Name As String
    Public Property Name() As String
        Get
            Return _Name
        End Get
        Set(ByVal value As String)
            _Name = value
        End Set
    End Property


    Private _Surname As String
    Public Property Surname() As String
        Get
            Return _Surname
        End Get
        Set(ByVal value As String)
            _Surname = value
        End Set
    End Property

    Private _DOB As Date
    Public Property DOB() As Date
        Get
            Return _DOB
        End Get
        Set(ByVal value As Date)
            _DOB = value
        End Set
    End Property

    Public Sub New()

        Name = ""
        Surname = ""
        DOB = Date.Now

    End Sub

    Public Sub New(ByVal thename As String, ByVal thesurname As String, ByVal thedate As Date)

        Name = thename
        Surname = thesurname
        DOB = thedate


    End Sub
End Class
