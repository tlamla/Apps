﻿Public Class Form1

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub AgentWithClassToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AgentWithClassToolStripMenuItem.Click
        Dim maint As New maintainAgent
        maint.MdiParent = Me
        maint.Show()

    End Sub

    Private Sub GentWithWizardToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GentWithWizardToolStripMenuItem.Click
        Dim wzrd As New frmAgentWithWizard
        wzrd.MdiParent = Me
        wzrd.Show()

    End Sub

    Private Sub PropertiesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PropertiesToolStripMenuItem.Click
        Dim propty As New FrmProperties
        propty.MdiParent = Me
        propty.Show()

    End Sub
End Class
