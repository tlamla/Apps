﻿Public Class frmAgentWithWizard

    Private Sub TblAgentBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblAgentBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.TblAgentBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.DuduDataSet)

    End Sub

    Private Sub frmAgentWithWizard_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DuduDataSet.tblAgent' table. You can move, or remove it, as needed.
        Me.TblAgentTableAdapter.Fill(Me.DuduDataSet.tblAgent)

    End Sub

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        Dim objreport As New frmAgentReport

        If rdoAll.Checked Then
            objreport.Tag = 0
        Else
            objreport.Tag = CInt(AgentIDTextBox.Text)

        End If
        objreport.ShowDialog()

    End Sub
End Class