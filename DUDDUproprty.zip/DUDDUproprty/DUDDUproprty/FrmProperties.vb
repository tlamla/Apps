﻿Public Class FrmProperties

    Private Sub TblAgentBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblAgentBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.TblAgentBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.DuduDataSet)

    End Sub

    Private Sub FrmProperties_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DuduDataSet.tblProperty' table. You can move, or remove it, as needed.
        Me.TblPropertyTableAdapter.Fill(Me.DuduDataSet.tblProperty)
        'TODO: This line of code loads data into the 'DuduDataSet.tblAgent' table. You can move, or remove it, as needed.
        Me.TblAgentTableAdapter.Fill(Me.DuduDataSet.tblAgent)

    End Sub
End Class