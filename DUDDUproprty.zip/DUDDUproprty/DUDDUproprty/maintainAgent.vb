﻿Imports System.Data.SqlClient
Public Class maintainAgent
    Private maintain As New maintain
    Private Sub maintainAgent_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DuduDataSet.tblAgent' table. You can move, or remove it, as needed.
        Me.TblAgentTableAdapter.Fill(Me.DuduDataSet.tblAgent)

    End Sub

    Private Sub cmbAgent_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbAgent.SelectedIndexChanged
        If cmbAgent.SelectedIndex <> -1 Then
            Dim maintainobj As New maintain
            Dim AGENTOBJ As New agent



            AGENTOBJ = maintainobj.GetAgentData(cmbAgent.SelectedValue)


            txtName.Text = AGENTOBJ.Name
            txtSurname.Text = AGENTOBJ.Surname
            DateTimePicker1.Value = CDate(AGENTOBJ.DOB)

        End If
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click


        maintain.UpdateAgent(cmbAgent.SelectedValue)


    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Dim newagent As New agent(CStr(txtName.Text), CStr(txtSurname.Text), CDate(DateTimePicker1.Value))


        maintain.add_agent(newagent)


    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        maintain.DeleteAgent(cmbAgent.SelectedValue)

    End Sub
    Private Sub clearfrom()
        txtName.Clear()
        txtSurname.Clear()
        Me.DateTimePicker1 = Nothing
        cmbAgent = Nothing

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Call clearfrom()

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim newfrm As New frmAgentReport
        newfrm.Tag = CInt(cmbAgent.SelectedValue)

        newfrm.ShowDialog()

    End Sub
End Class