﻿Public Class frmAgentReport

    Private Sub frmAgentReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'duduDataSet.tblAgent' table. You can move, or remove it, as needed.
        Me.tblAgentTableAdapter.Fill(Me.duduDataSet.tblAgent)

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class