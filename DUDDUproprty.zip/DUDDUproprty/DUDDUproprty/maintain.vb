﻿
Imports System.Data.SqlClient
Public Class maintain
    Private _ConnString As String
    Public Property ConnString() As String
        Get
            Return _ConnString
        End Get
        Set(ByVal value As String)
            _ConnString = value
        End Set
    End Property
    Public Sub New()
        ConnString = "Data Source=ELIAS-PC\SQLEXPRESS;Initial Catalog=dudu;Integrated Security=True;Pooling=False"


    End Sub

    Public Function GetAgentData(ByVal AgentID As Integer) As agent
        Dim reader As SqlDataReader
        Dim AGENTOBJ As New agent
        Dim conectionobj As New SqlConnection(ConnString)
        Dim qry As String = "select Name,surname,DOB from tblAgent where AgentId=@AgentID"

        Dim cmd As New SqlCommand(qry, conectionobj)
        cmd.Parameters.Add("AgentID", SqlDbType.Int).Value = CInt(AgentID)


        conectionobj.Open()
        reader = cmd.ExecuteReader
        If reader.Read Then

            AGENTOBJ.Name = reader("Name")
            AGENTOBJ.Surname = reader("Surname")
            AGENTOBJ.DOB = reader("DOB")

        End If
        Return AGENTOBJ

    End Function

    Public Sub UpdateAgent(ByVal theagent As agent)
        'Dim classobj As New Agentvb
        Dim qry As String = "update tblAgent set Name=@Name,Surname=@Surname,D_O_B=@DOB"
        Dim conectionobj As New SqlConnection(ConnString)
        Dim cmd As New SqlCommand(qry, conectionobj)

        cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = theagent.Name
        cmd.Parameters.Add("@Surname", SqlDbType.VarChar).Value = theagent.Surname
        cmd.Parameters.Add("DOB", SqlDbType.Date).Value = theagent.DOB

        conectionobj.Open()
        cmd.ExecuteNonQuery()

        'Return classobj

    End Sub
    Public Sub add_agent(ByVal person As agent)

        'Dim classobj As New Agentvb
        Dim qry As String = "insert into tblAgent (Name,Surname,DOB) values (@Name,@Surname,@DOB)"
        Dim conectionobj As New SqlConnection(ConnString)
        Dim cmd As New SqlCommand(qry, conectionobj)

        cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = CStr(person.Name)
        cmd.Parameters.Add("@Surname", SqlDbType.VarChar).Value = CStr(person.Surname)
        cmd.Parameters.Add("@DOB", SqlDbType.Date).Value = CDate(person.DOB)


        conectionobj.Open()
        cmd.ExecuteNonQuery()

        conectionobj.Close()


    End Sub


    Public Sub DeleteAgent(ByVal agentID As Integer)
        Dim qry As String = " delete from tblagent where AgentID=@AgentID"
        Dim conectionobj As New SqlConnection(ConnString)
        Dim cmd As New SqlCommand(qry, conectionobj)

        cmd.Parameters.Add("AgentID", SqlDbType.Int).Value = CInt(agentID)


        conectionobj.Open()
        cmd.ExecuteNonQuery()

    End Sub
End Class
