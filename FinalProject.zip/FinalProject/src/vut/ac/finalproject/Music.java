package vut.ac.finalproject;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Music extends Activity {
MediaPlayer mpplay;
int playing;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.music);
		Button btnplay =(Button) findViewById(R.id.btplay);
		Button btnpics =(Button) findViewById(R.id.btngallery);
		
		mpplay= new MediaPlayer();
		mpplay= MediaPlayer.create(this, R.raw.west);
		playing=0;
		
		btnplay.setOnClickListener(new OnClickListener() {
	
			
			@Override
			public void onClick(View arg0) {
			switch (playing) {
			case 0:
				mpplay.start();
				playing=1;
				break;			
			case 1:
				mpplay.pause();
				playing=0;
				
				break;

			}
				
				
			}
		});
		btnpics.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
			startActivity(new Intent(Music.this,Images.class));
				
			}
		});
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.music, menu);
		return true;
	}

}
