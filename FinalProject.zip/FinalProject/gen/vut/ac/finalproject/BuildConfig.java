/** Automatically generated file. DO NOT MODIFY */
package vut.ac.finalproject;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}