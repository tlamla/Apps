﻿Public Class Form1

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        'Declaration
        Dim f_value As Decimal = 0.0
        Dim C_rate As Decimal = 0.0
        Dim period As Decimal = 0.0
        Dim Interest_rate As Decimal = 0.0
        Dim price As Int32 = 0

        'Input

        f_value = txtValue.Text
        C_rate = txtCouponRate.Text
        period = txtperiod.Text
        Interest_rate = txtInterestRate.Text

        'Processes
        C_rate = Decimal.TryParse(txtCouponRate.Text, 0)
        f_value = Decimal.TryParse(txtValue.Text, 0)
        period = Decimal.TryParse(txtperiod.Text, 0)
        Interest_rate = Decimal.TryParse(txtInterestRate.Text, 0)
        price = Int32.TryParse(lblprice.Text, 0)


        price = (C_rate * f_value) * ((1 - (1 + Interest_rate) ^ -period) / Interest_rate) + f_value / (1 + Interest_rate) ^ period



        'Output
        lblprice.Text = "Bond price is: " + price.ToString()
    End Sub
End Class
