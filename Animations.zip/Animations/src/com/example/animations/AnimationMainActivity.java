package com.example.animations;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;

import android.view.View;
import android.view.View.OnClickListener;

import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class AnimationMainActivity extends Activity {
AnimationDrawable picanimation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animation_main);
       ImageView img=(ImageView)findViewById(R.id.imageView1);
      
       Button start=(Button)findViewById(R.id.btn1);
       Button stop=(Button)findViewById(R.id.btn2);
       Button tween=(Button)findViewById(R.id.btn3);
       //set background
       img.setBackgroundResource(R.drawable.animation);
       //get background
       picanimation=(AnimationDrawable)img.getBackground();
       
       start.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			picanimation.start();
			Toast toast=Toast.makeText(AnimationMainActivity.this, "are you working", Toast.LENGTH_LONG);
			toast.show();
		}
	});
       
       stop.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			picanimation.stop();
		}
	});
       tween.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			startActivity(new Intent(AnimationMainActivity.this,tween.class));
		}
	});
    }


    
}
