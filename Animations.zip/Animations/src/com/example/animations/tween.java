package com.example.animations;

import android.app.Activity;
import android.os.Bundle;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class tween extends Activity {
	public void onCreate(Bundle savedInstancesave){
	super.onCreate(savedInstancesave);
	setContentView(R.layout.tween)	;
	ImageView img=(ImageView)findViewById(R.id.imageView1);
	img.startAnimation(AnimationUtils.loadAnimation(this,R.anim.tweenanimation));
	}

}
